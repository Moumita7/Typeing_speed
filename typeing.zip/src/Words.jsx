export let keyWord=
"asd asdfjkl; ;lkjfdsa fdsajkl; asdfjkl; asdfjkl; asdfjkl; asdfjkl; asdfjk;l asdf jk; lasdfjkl; fjfkdls; alskdfj aaassss ddddffffjj jkklll;;;;lkj jkl;as asdfjk;l asdf jk; lasdfjkl; fjfkdls; alskdfj aaassss ;lkjfdsa fdsajkl; asdfjkl; asdfjkl; asdfjkl; asdfjk;l asdf jk; lasdfjkl; fjfkdls; alskdfj aaassss ;lkjfdsa kljasds kljsdasd klkj;ksd kkjlljsds lkkdsak lkjasdasd"
